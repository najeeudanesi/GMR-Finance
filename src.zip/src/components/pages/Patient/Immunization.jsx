import React from "react";

function Immunization() {
  return (
    <div>
      {" "}
      <div className="m-t-40">Immunization</div>
    </div>
  );
}

export default Immunization;
