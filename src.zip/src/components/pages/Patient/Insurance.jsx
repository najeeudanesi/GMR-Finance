import React from "react";

function Insurance() {
  return (
    <div>
      {" "}
      <div className="m-t-40">Insurance</div>
    </div>
  );
}

export default Insurance;
